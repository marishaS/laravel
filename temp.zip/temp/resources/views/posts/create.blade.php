@extends ('welcome')

@section('title','| Create new post')

@section('content')
<div class="row"> 

    
<div class="row">
        <div class="col-md-8 col-md-offset-2">
            <h1>Create New Post</h1>
            <hr>

            {!! Form::open(['route' => 'posts.store']) !!}

            {{ Form::label('email', 'Email')}}
            {{Form::text('email', null,array('class'=>'form-control'))}}
    
{!! Form::close() !!}

    
</div>

@endsection