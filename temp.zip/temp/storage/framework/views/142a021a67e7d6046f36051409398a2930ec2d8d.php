<?php $__env->startSection('title', '| About Me'); ?>

<div class="row">
<div class="col-md-12"> 
<h1> About Me!</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit laborum, laudantium consequatur quos, in, suscipit error fugiat est et omnis explicabo exercitationem nihil aspernatur aliquid itaque qui dicta minima. Doloribus?</p>
</div>
</div>



<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>